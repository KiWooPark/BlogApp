//
//  DetailStudyViewController.swift
//  BlogApp
//
//  Created by PKW on 2023/03/08.
//

import UIKit

class DetailStudyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
        
    }
}
