//
//  AddStudyViewController.swift
//  BlogApp
//
//  Created by PKW on 2023/02/27.
//

import UIKit

class AddStudyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    @IBAction func tapCloseButton(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    @IBAction func tapDoneButton(_ sender: Any) {
        
    }
}
